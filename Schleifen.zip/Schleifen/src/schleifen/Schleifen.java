/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schleifen;

/**
 *
 * @author Sanne
 */
public class Schleifen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        int[][] vieleZahlen={{1,2,2,3},{3,2,17,5},{5,2,6,17,7}};
//        siebzehn:
//        for(int i= 0; i<vieleZahlen.length;i++){
//            inner:
//            for (int j= 0; j<vieleZahlen[i].length;j++){
//                if(vieleZahlen[i][j]==17){ 
//                    System.out.println("Das ist nicht erlaubt");
//                    break inner;
//                }
//                System.out.print(vieleZahlen[i][j] +" - ");
//            }
//            System.out.println("");
//        }
//        System.out.println("Vielen Dank, dass Sie heute unser Programm genuzt haben");
//        System.out.println("Schritt 1: Noch gar nichts mit Blöcken");
//        Bloecke b; 
//        System.out.println("Schritt2: Ein Block wurde deklariert");
//        b=new Bloecke();
//        System.out.println("Schritt 3: Ein Block wurde instanziert");
//        b=new Bloecke();
//        System.out.println("SChritt 4: Ein weiterer Block wurde instanziert");
//          SpezialBloecke sb=null;//= new SpezialBloecke();
//          System.out.println(sb);
//          SpezialBloecke k = new SpezialBloecke();
//          k = new SpezialBloecke();
//          k = new SpezialBloecke();
            System.out.println(SpezialBloecke.sechzehn);
    }
//    }
    /**
     * Aufgabe: Beispiele für break, continue
     * Mit und ohne Label
     * 
     * Fibonacci-Zahlen, Abbruchkriterium: Summe aller bisher gefunden > 1000
     * Ausgeben werden soll, wieviele Zahlen bisdahin erstellt wurden
     * 
     * 
     * Wunzel von Quadratzahlen:
     * 
     * Ziel zb 25
     * Additon der ungeraden Zahlen bis Ziel erreicht,
     * Anzahl der Summanden ist Wurzel aus der Zielzahl
     * 1: 1
     * 2: 1+3 = 4
     * 3: 1+3+5 = 9
     * 4:1+3+5+7=16
     * 5:1+3+5+7+9=25
     * -> 5 ist Wurzel aus 25
     * 
     * Zeichenketten untersuchen auf ander Zeichenketten: Welche Wörter enhält ein Satz
     */
}
